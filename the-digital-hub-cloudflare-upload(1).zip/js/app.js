// App shell: header, footer, route table, session lifecycle.
import * as api from './api.js';
import { state } from './api.js';
import { route, render, navigate } from './router.js';
import { esc, $, icons, brandMark } from './ui.js';
import * as pub from './views-public.js';
import * as stu from './views-student.js';

route('/', pub.home);
route('/catalogue', pub.catalogue);
route('/p/:slug', pub.product);
route('/login', pub.login);
route('/faq', pub.faq);

route('/learn', stu.dashboard);
route('/learn/:slug', stu.learn);
route('/learn/:slug/:lessonId', stu.lesson);
route('/library', stu.library);

/* ---------- Header / footer ---------- */
function links() {
  const l = [['/catalogue', 'Catalogue'], ['/faq', 'FAQ']];
  if (state.authed) l.push(['/learn', 'My learning'], ['/library', 'Library']);
  return l;
}
function renderHeader() {
  const path = location.pathname;
  const act = h => (path === h || (h !== '/' && path.startsWith(h))) ? 'active' : '';
  const L = links();
  const authBtns = state.authed
    ? `${api.firstName() ? `<span class="hello">Hi, ${esc(api.firstName())}</span>` : ''}<button class="btn btn-ghost btn-sm" id="logout">Log out</button>`
    : `<a class="btn btn-primary btn-sm" href="/login" data-link>Student login</a>`;
  $('#site-header').innerHTML = `
    <div class="container nav">
      <a class="brand" href="/" data-link aria-label="The Digital Hub home">${brandMark}<span>The Digital Hub</span></a>
      <nav class="nav-links" aria-label="Main">${L.map(([h, t]) => `<a href="${h}" data-link class="${act(h)}">${t}</a>`).join('')}</nav>
      <span class="nav-spacer"></span>
      <div class="nav-actions">${authBtns}</div>
      <button class="nav-toggle" id="navtoggle" aria-label="Open menu" aria-expanded="false">${icons.menu}</button>
    </div>
    <div class="drawer" id="drawer">
      ${L.map(([h, t]) => `<a class="dlink" href="${h}" data-link>${t}</a>`).join('')}
      <a class="dlink" href="/#how" data-link>How it works</a>
      ${state.authed ? `<button class="btn btn-ghost" id="dout">Log out</button>` : `<a class="btn btn-primary" href="/login" data-link>Student login</a>`}
    </div>`;
  const dr = $('#drawer'), tg = $('#navtoggle');
  const setOpen = o => { dr.classList.toggle('open', o); tg.innerHTML = o ? icons.x : icons.menu; tg.setAttribute('aria-expanded', o); document.body.style.overflow = o ? 'hidden' : ''; };
  tg.addEventListener('click', () => setOpen(!dr.classList.contains('open')));
  dr.addEventListener('click', e => { if (e.target.closest('a')) setOpen(false); });
  const out = async () => { setOpen(false); await api.logout(); renderHeader(); navigate('/', { replace: true }); };
  $('#logout')?.addEventListener('click', out);
  $('#dout')?.addEventListener('click', out);
}

function renderFooter() {
  $('#site-footer').innerHTML = `
    <div class="container">
      <div class="footer-grid">
        <div><a class="brand" href="/" data-link>${brandMark}<span>The Digital Hub</span></a>
          <p style="max-width:30em">Learn. Create. Build. Practical courses and digital products for anyone developing digital skills.</p></div>
        <div><h4>Explore</h4><a href="/catalogue" data-link>Catalogue</a><a href="/faq" data-link>FAQ</a><a href="/#how" data-link>How it works</a></div>
        <div><h4>Students</h4><a href="/login" data-link>Student login</a><a href="/learn" data-link>My learning</a><a href="/library" data-link>Resource library</a></div>
      </div>
      <div class="fine"><span>© ${new Date().getFullYear()} The Digital Hub</span><span>Learn. Create. Build.</span></div>
    </div>`;
}

/* ---------- Boot ---------- */
window.addEventListener('hub:auth', renderHeader);
window.addEventListener('hub:route', renderHeader);

async function boot() {
  renderFooter();
  try { await api.loadCatalogue(); } catch (e) { console.error(e); }
  renderHeader();
  await render();
  if (location.hash === '#how') document.getElementById('how')?.scrollIntoView();
}
boot();
