// Data layer. Content and access come from the server (/api/*); progress is kept on the student's device.
export const state = { authed: false, student: null, faq: [], settings: {}, categories: [], products: [], loaded: false };

async function call(path, opts = {}) {
  const r = await fetch(path, { credentials: 'same-origin', cache: 'no-store', ...opts });
  let data = null; try { data = await r.json(); } catch { /* not json */ }
  if (!r.ok) throw new Error(data?.error || `Request failed (${r.status})`);
  return data;
}

const norm = (p, cats) => ({
  ...p,
  price_cents: Math.round((p.price || 0) * 100),
  currency: p.currency || 'USD',
  price_note: p.priceNote || '',
  access_text: p.access || 'Lifetime access',
  access_label: /lifetime/i.test(p.access || 'Lifetime') ? 'Lifetime' : 'Time-limited',
  cover_url: p.coverUrl || null,
  category: cats.find(c => c.slug === p.category) || null,
  category_id: p.category || null,
  lessons: (p.lessons || []).map((l, i) => ({ ...l, position: i + 1, duration_min: l.duration || null })),
  lesson_count: (p.lessons || []).length,
  resources: (p.resources || []).map(r => ({ ...r, lesson_id: r.lessonId || null, external_url: r.url || null, file_path: r.hasFile ? r.id : null }))
});

export async function loadCatalogue() {
  const d = await call('/api/catalogue');
  state.authed = d.authed;
  state.student = d.student || null;
  state.faq = d.faq || [];
  state.settings = d.settings || {};
  state.categories = (d.categories || []).map(c => ({ ...c, id: c.slug }));
  state.products = (d.products || []).map(p => norm(p, state.categories));
  state.loaded = true;
}

export const login = async (name, code) => { await call('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, code }) }); await loadCatalogue(); };
export const logout = async () => { await call('/api/logout', { method: 'POST' }); await loadCatalogue(); };

export const firstName = () => (state.student?.name || '').split(' ')[0];
export const listProducts = async () => state.products;
export const listCategories = async () => state.categories;
export const getProduct = async slug => state.products.find(p => p.slug === slug) || null;
export const getSettings = async () => state.settings;

export function allResources() {
  return state.products.flatMap(p => (p.resources || []).map(r => ({ ...r, product: { id: p.slug, title: p.title, slug: p.slug, type: p.type } })));
}

/* ---------- Progress & "continue where you left off" (stored on this device) ---------- */
const PK = 'hub:progress:v1', LK = 'hub:last:v1';
const read = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage blocked */ } };

export const doneSet = () => new Set(Object.keys(read(PK, {})));
export function setComplete(lessonId, done) {
  const p = read(PK, {}); if (done) p[lessonId] = 1; else delete p[lessonId]; write(PK, p);
}
export function progressFor(product) {
  const d = doneSet(); const total = product.lessons.length;
  return { done: product.lessons.filter(l => d.has(l.id)).length, total };
}
export function touchLast(slug, lessonId) { const l = read(LK, {}); l[slug] = { lessonId, at: Date.now() }; write(LK, l); }
export const lastViewed = () => read(LK, {});
