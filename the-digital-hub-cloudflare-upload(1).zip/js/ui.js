// Small UI helpers shared by all views.

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const I = (d, extra = '') => `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${d}</svg>`;
export const icons = {
  play: I('<circle cx="12" cy="12" r="9.5"/><path d="M10 8.5l5.5 3.5-5.5 3.5z" fill="currentColor"/>'),
  book: I('<path d="M4 5.5A2.5 2.5 0 016.5 3H20v16H6.5A2.5 2.5 0 004 21.5z"/><path d="M4 21.5V5.5M8 7h8"/>'),
  file: I('<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>'),
  template: I('<rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><path d="M3.5 9h17M9.5 9v11.5"/>'),
  pack: I('<path d="M21 8l-9-5-9 5 9 5z"/><path d="M3 8v8l9 5 9-5V8M12 13v8"/>'),
  grid: I('<rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/>'),
  check: I('<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
  checkc: I('<circle cx="12" cy="12" r="9.5"/><path d="M8 12.5l3 3 5-6"/>'),
  lock: I('<rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 018 0v2.5"/>'),
  infinity: I('<path d="M12 12c-2-3-3.5-4-5.5-4a4 4 0 000 8c2 0 3.5-1 5.5-4zm0 0c2 3 3.5 4 5.5 4a4 4 0 000-8c-2 0-3.5 1-5.5 4z"/>'),
  clock: I('<circle cx="12" cy="12" r="9.5"/><path d="M12 7v5.5l3.5 2"/>'),
  arrow: I('<path d="M5 12h14M13 6l6 6-6 6"/>'),
  arrowl: I('<path d="M19 12H5M11 6l-6 6 6 6"/>'),
  menu: I('<path d="M4 7h16M4 12h16M4 17h16"/>'),
  x: I('<path d="M6 6l12 12M18 6L6 18"/>'),
  download: I('<path d="M12 3v12M7 10.5l5 5 5-5M4.5 20h15"/>'),
  link: I('<path d="M10 14a4.5 4.5 0 006.4 0l3-3a4.5 4.5 0 00-6.4-6.4l-1 1"/><path d="M14 10a4.5 4.5 0 00-6.4 0l-3 3a4.5 4.5 0 006.4 6.4l1-1"/>'),
  sparkle: I('<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>'),
  user: I('<circle cx="12" cy="8" r="4"/><path d="M4.5 21a7.5 7.5 0 0115 0"/>'),
  mail: I('<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 7l8.5 6 8.5-6"/>'),
  compass: I('<circle cx="12" cy="12" r="9.5"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>')
};

export function typeMeta(t) {
  return ({
    video_course: { label: 'Video course', icon: icons.play, plural: 'Video courses' },
    workbook: { label: 'Workbook', icon: icons.book, plural: 'Workbooks' },
    guide: { label: 'Guide / ebook', icon: icons.file, plural: 'Guides & ebooks' },
    template: { label: 'Templates', icon: icons.template, plural: 'Templates' },
    resource_pack: { label: 'Resource pack', icon: icons.pack, plural: 'Resource packs' },
    other: { label: 'Digital product', icon: icons.grid, plural: 'Other products' }
  })[t] || { label: 'Digital product', icon: icons.grid, plural: 'Other' };
}
export const TYPES = ['video_course', 'workbook', 'guide', 'template', 'resource_pack', 'other'];

export function kindMeta(k) {
  return ({
    workbook: { label: 'Workbook', icon: icons.book },
    guide: { label: 'Guide', icon: icons.file },
    template: { label: 'Template', icon: icons.template },
    download: { label: 'Download', icon: icons.download },
    link: { label: 'Link', icon: icons.link }
  })[k] || { label: 'Download', icon: icons.download };
}

export function money(cents, currency = 'USD') {
  if (!cents) return 'Free';
  const v = cents / 100;
  try {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency, minimumFractionDigits: v % 1 ? 2 : 0 }).format(v);
  } catch { return `${currency} ${v}`; }
}

export function accessText(p) {
  return p.access_text || 'Lifetime access';
}

export function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function slugify(s) {
  return String(s || '').toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 70);
}

export const lines = v => String(v || '').split('\n').map(s => s.trim()).filter(Boolean);
export const initials = n => (n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';

// Brand mark (inline SVG) — a rounded hub with three orbiting nodes.
export const brandMark = `<svg class="brand-mark" viewBox="0 0 40 40" aria-hidden="true"><rect width="40" height="40" rx="12" fill="#0f3d3e"/><circle cx="20" cy="20" r="5" fill="#b8975a"/><circle cx="20" cy="9" r="2.6" fill="#faf6ee"/><circle cx="10.5" cy="25.5" r="2.6" fill="#c98a8a"/><circle cx="29.5" cy="25.5" r="2.6" fill="#faf6ee"/><path d="M20 11.6V15M12.8 24.2l3.3-1.9M27.2 24.2l-3.3-1.9" stroke="#faf6ee" stroke-width="1.4" stroke-linecap="round" opacity=".7"/></svg>`;

// Cover art: uploaded image if present, otherwise a themed generated cover.
export function coverArt(p, cls = '') {
  const m = typeMeta(p.type);
  if (p.cover_url) return `<div class="cover-card has-img theme-${esc(p.theme || 'teal')} ${cls}"><img class="cover-img" src="${esc(p.cover_url)}" alt="${esc(p.title)} cover"></div>`;
  const glyph = m.icon.replace('class="icon"', 'class="art-glyph"').replace(/stroke-width="1.8"/, 'stroke-width="1"');
  return `<div class="cover-card theme-${esc(p.theme || 'teal')} ${cls}" role="img" aria-label="${esc(p.title)} cover">
    <div class="art-lines"></div>${glyph}
    <div class="art"><span class="art-tag">${esc(m.label)}</span>
      <div><div class="art-bar"></div><div class="art-title">${esc(p.title)}</div></div></div></div>`;
}

export function productCard(p) {
  const m = typeMeta(p.type);
  const meta = p.type === 'video_course' ? `${p.lesson_count || 0} lessons` : m.label;
  return `<a class="card pcard" href="/p/${esc(p.slug)}" data-link>
    ${coverArt(p)}
    <div class="pcard-body">
      <span class="badge ${p.type === 'video_course' ? '' : 'rose'}">${m.icon}${esc(m.label)}</span>
      <h3>${esc(p.title)}</h3>
      <p class="sub">${esc(p.subtitle || '')}</p>
      <div class="pcard-foot"><span>${esc(meta)} · ${esc(p.access_label || 'Lifetime')}</span>
      <span class="price">${money(p.price_cents, p.currency)}</span></div>
    </div></a>`;
}

export const progressBar = pct => `<div class="progress" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>`;

// Turn a pasted video link into something embeddable.
export function videoEmbed(url) {
  if (!url) return null;
  const u = url.trim();
  if (/^https:\/\/player\.vimeo\.com\/video\/\d+/.test(u)) return { kind: 'iframe', src: u };
  let m = u.match(/(?:youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/);
  if (m) return { kind: 'iframe', src: `https://www.youtube-nocookie.com/embed/${m[1]}?rel=0&modestbranding=1` };
  m = u.match(/vimeo\.com\/(?:video\/)?(\d+)(?:\/(\w+))?/);
  if (m) return { kind: 'iframe', src: `https://player.vimeo.com/video/${m[1]}${m[2] ? '?h=' + m[2] : ''}` };
  m = u.match(/drive\.google\.com\/file\/d\/([\w-]+)/);
  if (m) return { kind: 'iframe', src: `https://drive.google.com/file/d/${m[1]}/preview` };
  if (/\.(mp4|webm|ogg|m4v)(\?|$)/i.test(u)) return { kind: 'video', src: u };
  if (/^https:\/\//i.test(u)) return { kind: 'iframe', src: u };
  return null;
}

export function toast(msg, kind = '') {
  let wrap = $('.toast-wrap');
  if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; wrap.setAttribute('role', 'status'); document.body.appendChild(wrap); }
  const t = document.createElement('div');
  t.className = 'toast ' + kind; t.textContent = msg; wrap.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

export function modal(html, onMount) {
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.innerHTML = `<div class="modal" role="dialog" aria-modal="true"><button class="modal-x" aria-label="Close">${icons.x}</button>${html}</div>`;
  const close = () => { back.remove(); document.removeEventListener('keydown', esc_); };
  const esc_ = e => { if (e.key === 'Escape') close(); };
  back.addEventListener('click', e => { if (e.target === back) close(); });
  $('.modal-x', back).addEventListener('click', close);
  document.addEventListener('keydown', esc_);
  document.body.appendChild(back);
  onMount?.(back, close);
  return close;
}

export const spinner = '<div class="loading"><div class="spinner" aria-label="Loading"></div></div>';

export function errMsg(e) {
  const m = e?.message || String(e);
  return m;
}

export const faqItem = f => `<details class="faq"><summary>${esc(f.q)}</summary><div class="faq-a">${String(f.a).split(/\n\n+/).map(x => `<p>${esc(x)}</p>`).join('')}</div></details>`;
