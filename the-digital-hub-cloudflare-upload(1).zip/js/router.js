// Minimal history-API router. Views return { html, mount?, title? }.
import { esc, spinner } from './ui.js';

const routes = [];
export class Redirect { constructor(to) { this.to = to; } }

export function route(pattern, fn) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ re, keys, fn });
}

export function navigate(path, { replace = false } = {}) {
  history[replace ? 'replaceState' : 'pushState']({}, '', path);
  return render();
}

let token = 0;
export async function render() {
  const app = document.getElementById('app');
  const my = ++token;
  const path = location.pathname.replace(/\/+$/, '') || '/';
  const query = Object.fromEntries(new URLSearchParams(location.search));
  let hit = null, params = {};
  for (const r of routes) {
    const m = path.match(r.re);
    if (m) { hit = r; r.keys.forEach((k, i) => params[k] = decodeURIComponent(m[i + 1])); break; }
  }
  app.innerHTML = spinner;
  try {
    const res = hit ? await hit.fn({ params, query, path }) : notFound();
    if (my !== token) return;
    app.innerHTML = res.html;
    document.title = (res.title ? res.title + ' · ' : '') + 'The Digital Hub';
    window.scrollTo(0, 0);
    res.mount?.(app);
  } catch (e) {
    if (my !== token) return;
    if (e instanceof Redirect) return navigate(e.to, { replace: true });
    console.error(e);
    app.innerHTML = `<div class="container narrow" style="padding:80px 24px"><h2>Something went wrong</h2><p class="muted">${esc(e.message || e)}</p><a class="btn btn-ghost" href="/" data-link>Back to home</a></div>`;
  }
  window.dispatchEvent(new Event('hub:route'));
}

export const notFound = () => ({
  title: 'Not found',
  html: `<div class="container narrow center" style="padding:90px 24px"><span class="eyebrow">404</span><h1 style="font-size:2.6rem">We couldn't find that page</h1><p class="muted">The link may be old, or the product may no longer be available.</p><a class="btn btn-primary" href="/catalogue" data-link>Browse the catalogue</a></div>`
});

// Intercept internal link clicks.
document.addEventListener('click', e => {
  const a = e.target.closest('a');
  if (!a || a.target === '_blank' || a.hasAttribute('download') || e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;
  const href = a.getAttribute('href');
  if (!href || !href.startsWith('/') || href.startsWith('//') || href.startsWith('/api/')) return;
  e.preventDefault();
  navigate(href);
});
window.addEventListener('popstate', render);
