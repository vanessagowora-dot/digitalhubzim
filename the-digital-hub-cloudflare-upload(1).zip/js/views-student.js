// Student area (unlocked with the access code): learning space, course viewer, lesson player, library.
// Progress is stored on the student's own device.
import * as api from './api.js';
import { state } from './api.js';
import { Redirect, notFound } from './router.js';
import { esc, $, icons, faqItem, kindMeta, typeMeta, coverArt, progressBar, videoEmbed, toast } from './ui.js';

function requireAuth(path) {
  if (!state.authed) throw new Redirect('/login?next=' + encodeURIComponent(path));
}
const pct = (done, total) => total ? Math.round((done / total) * 100) : 0;

/* ---------- shared: resource rows ---------- */
export function resourceRow(r, { showProduct = false } = {}) {
  const k = kindMeta(r.kind);
  const sub = showProduct && r.product ? esc(r.product.title) : esc(k.label);
  let action;
  if (r.file_path) action = `<a class="btn btn-ghost btn-sm" href="/api/file?id=${encodeURIComponent(r.id)}" download>${icons.download} Download</a>`;
  else if (r.external_url) action = `<a class="btn btn-ghost btn-sm" href="${esc(r.external_url)}" target="_blank" rel="noopener">${icons.link} Open</a>`;
  else action = `<span class="badge gold">Coming soon</span>`;
  return `<div class="res k-${esc(r.kind)}"><span class="ri">${k.icon}</span>
    <div class="res-main"><h4>${esc(r.title)}</h4><div class="res-sub">${sub}</div></div>${action}</div>`;
}

/* ============ My learning (dashboard) ============ */
export async function dashboard({ path }) {
  requireAuth(path);
  const products = await api.listProducts();
  const courses = products.filter(p => p.type === 'video_course');
  const others = products.filter(p => p.type !== 'video_course');
  const last = api.lastViewed();
  const downloads = api.allResources().filter(r => r.file_path || r.external_url);

  // Continue learning: most recently viewed course, else first unfinished course.
  let cont = null;
  const recent = courses.filter(c => last[c.slug]).sort((a, b) => last[b.slug].at - last[a.slug].at)[0];
  if (recent) cont = { p: recent, lessonId: last[recent.slug].lessonId };
  else {
    const p = courses.find(c => { const g = api.progressFor(c); return g.done < g.total; }) || courses[0];
    if (p) cont = { p, lessonId: null };
  }

  const courseCard = p => {
    const { done, total } = api.progressFor(p), v = pct(done, total);
    return `<a class="card pcard" href="/learn/${esc(p.slug)}" data-link>${coverArt(p)}
      <div class="pcard-body"><h3>${esc(p.title)}</h3>
        <div class="progress-row">${progressBar(v)}<span>${v}%</span></div>
        <div class="pcard-foot"><span>${done} of ${total} lessons</span><span class="link-btn" style="text-decoration:none">${v === 0 ? 'Start' : v === 100 ? 'Review' : 'Continue'} →</span></div></div></a>`;
  };

  const html = `
  <div class="container dash">
    <div class="dash-hello">
      <div><span class="eyebrow">Your learning space</span><h1>${api.firstName() ? `Welcome, ${esc(api.firstName())}` : 'Welcome back'}</h1></div>
      <a class="btn btn-ghost btn-sm" href="/catalogue" data-link>Browse catalogue</a>
    </div>

    ${cont ? (() => {
      const { done, total } = api.progressFor(cont.p), v = pct(done, total);
      const href = `/learn/${cont.p.slug}${cont.lessonId ? '/' + cont.lessonId : ''}`;
      return `<div class="card continue">${coverArt(cont.p)}
        <div class="continue-body"><span class="badge gold">Continue learning</span>
          <h2>${esc(cont.p.title)}</h2>
          <div class="progress-row" style="max-width:420px">${progressBar(v)}<span>${done}/${total} lessons</span></div>
          <div><a class="btn btn-primary" href="${href}" data-link>${done || cont.lessonId ? 'Pick up where you left off' : 'Start the course'} ${icons.arrow}</a></div></div></div>`;
    })() : ''}

    ${courses.length ? `<div class="block-title"><h2>My courses</h2></div><div class="grid">${courses.map(courseCard).join('')}</div>` : ''}

    ${others.length ? `<div class="block-title"><h2>My digital products</h2></div>
      <div class="grid">${others.map(p => `<a class="card pcard" href="/learn/${esc(p.slug)}" data-link>${coverArt(p)}
        <div class="pcard-body"><span class="badge rose">${typeMeta(p.type).label}</span><h3>${esc(p.title)}</h3>
        <div class="pcard-foot"><span>${esc(p.access_text)}</span><span class="link-btn" style="text-decoration:none">Open →</span></div></div></a>`).join('')}</div>` : ''}

    ${!courses.length && !others.length ? `<div class="empty">Courses and products will appear here.</div>` : ''}

    ${downloads.length ? `<div class="block-title"><h2>Available downloads</h2><a class="link-btn" href="/library" data-link>Open library</a></div>
      <div class="res-list">${downloads.slice(0, 4).map(r => resourceRow(r, { showProduct: true })).join('')}</div>` : ''}

    <p class="small muted" style="margin-top:40px">Your lesson progress is saved on this device and browser. Questions about AI or your course? <a href="/faq" data-link>Read the FAQ</a>.</p>
  </div>`;
  return { title: 'My learning', html };
}

/* ============ Course / product overview ============ */
export async function learn({ params, path }) {
  requireAuth(path);
  const p = await api.getProduct(params.slug);
  if (!p) return notFound();
  const isCourse = p.type === 'video_course';
  const done = api.doneSet();
  const lessons = p.lessons;
  const { done: nDone } = api.progressFor(p);
  const v = pct(nDone, lessons.length);
  const last = api.lastViewed()[p.slug];
  const next = lessons.find(l => l.id === last?.lessonId) || lessons.find(l => !done.has(l.id)) || lessons[0];
  const resources = p.resources || [];

  const html = `
  <style>@media(max-width:860px){.learn-top{grid-template-columns:1fr!important}}</style>
  <div class="container learn-head">
    <div class="crumbs"><a href="/learn" data-link>My learning</a> / ${esc(p.title)}</div>
    <div style="display:grid;grid-template-columns:${isCourse ? '1fr 340px' : '1fr'};gap:36px;align-items:start" class="learn-top">
      <div>
        <h1 style="font-size:clamp(1.9rem,4vw,2.8rem)">${esc(p.title)}</h1>
        ${p.subtitle ? `<p class="muted" style="font-size:1.1rem">${esc(p.subtitle)}</p>` : ''}
        ${isCourse ? `<div class="progress-row" style="max-width:460px;margin:18px 0">${progressBar(v)}<span>${nDone} of ${lessons.length} complete</span></div>
          ${next ? `<a class="btn btn-primary" href="/learn/${esc(p.slug)}/${esc(next.id)}" data-link>${nDone ? 'Continue learning' : 'Start course'} ${icons.arrow}</a>` : ''}` : ''}
        <p class="small muted" style="margin-top:16px">${esc(p.access_text)}</p>
      </div>
      ${isCourse ? coverArt(p) : ''}
    </div>
  </div>
  <div class="container" style="padding:12px 24px 90px">
    ${isCourse ? `<div class="block-title"><h2>Lessons</h2></div>
      <div class="curriculum">${lessons.map((l, i) => `
        <a class="cur-item" href="/learn/${esc(p.slug)}/${esc(l.id)}" data-link style="color:inherit">
          <span class="cur-num" style="${done.has(l.id) ? 'background:var(--ok);color:#fff' : ''}">${done.has(l.id) ? icons.check : i + 1}</span>
          <div><h4>${esc(l.title)}</h4>${l.summary ? `<p>${esc(l.summary)}</p>` : ''}</div>
          <span class="cur-meta">${l.parts > 1 ? l.parts + ' parts' : l.duration_min ? `${icons.clock} ${l.duration_min} min` : ''}${icons.arrow}</span></a>`).join('')}</div>` : `
      <div class="block-title"><h2>About</h2></div>${(p.description || '').split(/\n\n+/).map(x => `<p class="muted">${esc(x)}</p>`).join('')}`}
    <div class="block-title"><h2>${isCourse ? 'Course resources' : 'Your downloads'}</h2></div>
    ${resources.length ? `<div class="res-list">${resources.map(r => resourceRow(r)).join('')}</div>` : `<div class="empty">Resources will appear here.</div>`}
    ${(state.faq || []).length ? `<div class="block-title" id="faq" style="margin-top:56px"><h2>Frequently asked questions</h2></div>
      ${state.faq.map(g => `<h3 style="font-size:1.1rem;margin:22px 0 12px;color:var(--cinnamon)">${esc(g.group)}</h3>${g.items.map(faqItem).join('')}`).join('')}` : ''}
  </div>`;
  return { title: p.title, html };
}

/* ============ Lesson player ============ */
export async function lesson({ params, path }) {
  requireAuth(path);
  const p = await api.getProduct(params.slug);
  if (!p) return notFound();
  const lessons = p.lessons;
  const idx = lessons.findIndex(l => l.id === params.lessonId);
  if (idx < 0) throw new Redirect('/learn/' + p.slug);
  const L = lessons[idx], prev = lessons[idx - 1], next = lessons[idx + 1];
  api.touchLast(p.slug, L.id);
  const parts = (L.videos && L.videos.length) ? L.videos : [];
  const playerHtml = i => {
    const part = parts[i], embed = part ? videoEmbed(part.url) : null;
    if (!embed) return `<div class="player-ph">${icons.play}<b>Video coming soon</b><span>This lesson's video is being recorded. Check back shortly.</span></div>`;
    return embed.kind === 'video'
      ? `<video controls playsinline preload="metadata" controlslist="nodownload" src="${esc(embed.src)}"></video>`
      : `<iframe src="${esc(embed.src)}" title="${esc(L.title)}${parts.length > 1 ? ' – part ' + (i + 1) : ''}" allow="autoplay; fullscreen; picture-in-picture; clipboard-write; encrypted-media; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
  };
  const partLabel = (pt, i) => `Part ${i + 1}${pt.title ? ': ' + pt.title : ''}`;
  const resources = p.resources || [];
  const mine = resources.filter(r => r.lesson_id === L.id);
  const general = resources.filter(r => !r.lesson_id);

  const html = `
  <div class="container learn-head" style="padding-bottom:0">
    <div class="crumbs"><a href="/learn" data-link>My learning</a> / <a href="/learn/${esc(p.slug)}" data-link>${esc(p.title)}</a> / Lesson ${idx + 1}</div>
  </div>
  <div class="container learn-grid" style="padding-top:8px">
    <div>
      <div class="player" id="player">${playerHtml(0)}</div>
      ${parts.length > 1 ? `<div class="parts" role="tablist" aria-label="Lesson parts">${parts.map((pt, i) => `<button class="part ${i === 0 ? 'on' : ''}" role="tab" data-part="${i}" aria-selected="${i === 0}"><span class="part-n">${i + 1}</span><span>${esc(partLabel(pt, i))}</span></button>`).join('')}</div>` : ''}
      <h1 class="lesson-title">${idx + 1}. ${esc(L.title)}</h1>
      ${L.summary ? `<p class="muted">${esc(L.summary)}</p>` : ''}
      <div class="lesson-bar">
        <button class="btn btn-ghost btn-done" id="done"></button>
        <div class="nav-pair">
          ${prev ? `<a class="btn btn-ghost" href="/learn/${esc(p.slug)}/${esc(prev.id)}" data-link>${icons.arrowl} Previous</a>` : ''}
          ${next ? `<a class="btn btn-primary" href="/learn/${esc(p.slug)}/${esc(next.id)}" data-link>Next lesson ${icons.arrow}</a>`
                 : `<a class="btn btn-primary" href="/learn/${esc(p.slug)}" data-link>Back to course</a>`}
        </div>
      </div>
      ${mine.length ? `<div class="block-title" style="margin-top:34px"><h2 style="font-size:1.25rem">Lesson downloads</h2></div><div class="res-list">${mine.map(r => resourceRow(r)).join('')}</div>` : ''}
      ${general.length ? `<div class="block-title" style="margin-top:34px"><h2 style="font-size:1.25rem">Course resources</h2></div><div class="res-list">${general.map(r => resourceRow(r)).join('')}</div>` : ''}
    </div>
    <aside class="card side">
      <div class="side-head"><h3>${esc(p.title)}</h3><div class="progress-row"><div id="pb" style="flex:1"></div><span id="pt"></span></div></div>
      <div class="side-list" id="sl"></div>
      <div class="side-foot"><a href="/faq" data-link>Questions? See the FAQ ${icons.arrow}</a></div>
    </aside>
  </div>`;

  const mount = root => {
    const done = api.doneSet();
    const paint = () => {
      const n = lessons.filter(l => done.has(l.id)).length, v = pct(n, lessons.length);
      $('#pb', root).innerHTML = progressBar(v);
      $('#pt', root).textContent = `${v}%`;
      $('#sl', root).innerHTML = lessons.map((l, i) => `
        <a class="side-item ${l.id === L.id ? 'current' : ''} ${done.has(l.id) ? 'done' : ''}" href="/learn/${esc(p.slug)}/${esc(l.id)}" data-link>
          <span class="side-dot">${done.has(l.id) ? icons.check : ''}</span><span>${i + 1}. ${esc(l.title)}</span></a>`).join('');
      const b = $('#done', root), d = done.has(L.id);
      b.classList.toggle('is-done', d);
      b.innerHTML = d ? `${icons.checkc} Completed` : `${icons.checkc} Mark as complete`;
    };
    paint();
    root.querySelectorAll('.part').forEach(btn => btn.addEventListener('click', () => {
      const i = Number(btn.dataset.part);
      $('#player', root).innerHTML = playerHtml(i);
      root.querySelectorAll('.part').forEach(b => { const on = b === btn; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); });
    }));
    $('#done', root).addEventListener('click', () => {
      const want = !done.has(L.id);
      api.setComplete(L.id, want);
      want ? done.add(L.id) : done.delete(L.id);
      paint();
      if (want && lessons.every(l => done.has(l.id))) toast('Course complete — well done!', 'ok');
      else if (want) toast('Lesson marked complete', 'ok');
    });
  };
  return { title: L.title, html, mount };
}

/* ============ Resource library ============ */
export async function library({ path }) {
  requireAuth(path);
  const products = await api.listProducts();
  const groups = products.map(p => ({ product: p, items: p.resources || [] })).filter(g => g.items.length);
  const html = `
  <section class="page-head"><div class="container"><span class="eyebrow">Resource library</span><h1>Your downloads &amp; materials</h1>
    <p class="muted">Workbooks, guides, templates and links from everything you have access to.</p></div></section>
  <div class="container" style="padding-bottom:90px">
    ${groups.length ? groups.map(g => `
      <div class="block-title" style="margin-top:34px"><h2 style="font-size:1.35rem">${esc(g.product.title)}</h2>
        <a class="link-btn" href="/learn/${esc(g.product.slug)}" data-link>Open →</a></div>
      <div class="res-list">${g.items.map(r => resourceRow(r)).join('')}</div>`).join('')
    : `<div class="empty"><b>Nothing here yet.</b><br>Resources will appear here as they are added.</div>`}
  </div>`;
  return { title: 'Library', html };
}
