// Public pages: home, catalogue, product page, student login.
import * as api from './api.js';
import { state } from './api.js';
import { navigate, Redirect, notFound } from './router.js';
import { esc, $, icons, faqItem, typeMeta, TYPES, money, accessText, coverArt, productCard, errMsg } from './ui.js';

const authed = () => state.authed;
const landing = products => {
  const courses = products.filter(p => p.type === 'video_course');
  return courses.length === 1 ? '/learn/' + courses[0].slug : '/learn';
};
const safeNext = (q, dflt = '/learn') => (q.next && q.next !== '/learn' && q.next.startsWith('/') && !q.next.startsWith('//')) ? q.next : dflt;

/* ============ Home ============ */
export async function home() {
  const [products, cats] = await Promise.all([api.listProducts(), api.listCategories()]);
  const featured = [...products].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0)).slice(0, 3);
  const first = products.find(p => p.featured) || products[0];
  const countFor = c => products.filter(p => p.category_id === c.id).length;
  const hero3 = [
    first ? coverArt(first, 'c1') : '',
    coverArt({ title: 'Courses', type: 'video_course', theme: 'teal' }, 'c2 sm'),
    coverArt({ title: 'Guides & ebooks', type: 'guide', theme: 'rose' }, 'c3 sm'),
    coverArt({ title: 'Templates', type: 'template', theme: 'gold' }, 'c4 sm')
  ];
  const areaIcons = [icons.sparkle, icons.compass, icons.book, icons.template];
  const st = await api.getSettings();
  const dflt = landing(products);

  return {
    title: 'Learn. Create. Build.',
    mount: root => { if (!authed()) bindLogin(root, dflt, {}); },
    html: `
    <section class="hero"><div class="container hero-inner">
      <div>
        <span class="eyebrow">Welcome to The Digital Hub</span>
        <h1>Learn. Create. <em>Build.</em></h1>
        <p class="lead">Practical courses, workbooks, guides and templates to help you build real digital skills — and turn them into something of your own.</p>
        <div class="hero-cta">
          <a class="btn btn-primary" href="/catalogue" data-link>Browse the catalogue ${icons.arrow}</a>
          ${authed() ? `<a class="btn btn-ghost" href="/learn" data-link>Go to my learning</a>`
                     : `<a class="btn btn-ghost" href="/login" data-link>Student login</a>`}
        </div>
        <div class="hero-types">
          <span class="type-chip">${icons.play} Courses</span>
          <span class="type-chip">${icons.file} Guides &amp; ebooks</span>
          <span class="type-chip">${icons.template} Templates</span>
        </div>
        <div class="hero-note">
          <span>${icons.infinity} Lifetime access options</span>
          <span>${icons.check} Beginner friendly</span>
          <span>${icons.sparkle} Learn at your own pace</span>
        </div>
      </div>
      ${authed() ? `<div class="hero-art" aria-hidden="true">${hero3.join('')}</div>` : `<div class="hero-login-wrap">${loginCard(st, { hero: true })}</div>`}
    </div></section>

    <section class="section"><div class="container intro-grid">
      <div>
        <span class="eyebrow">What is The Digital Hub?</span>
        <h2>One place to learn, create and grow your digital skills</h2>
        <p class="muted">The Digital Hub is a growing home for online courses and digital products. Whether you are just starting out, studying, or building a business, you'll find clear, practical learning you can put to use straight away.</p>
        <p class="muted">New courses and resources are added regularly, and everything you have access to lives together in your learning space.</p>
        <a class="link-btn" href="/catalogue" data-link>See what's available →</a>
      </div>
      <div class="stats">
        <div class="pillar"><div class="pi">${icons.play}</div><h4>Video courses</h4><p>Step-by-step lessons you can pause, replay and revisit.</p></div>
        <div class="pillar"><div class="pi">${icons.book}</div><h4>Workbooks</h4><p>Guided exercises that turn ideas into action.</p></div>
        <div class="pillar"><div class="pi">${icons.file}</div><h4>Guides &amp; ebooks</h4><p>Focused reading you can keep and refer back to.</p></div>
        <div class="pillar"><div class="pi">${icons.template}</div><h4>Templates</h4><p>Ready-made files that save you hours.</p></div>
      </div>
    </div></section>

    <section class="section tint"><div class="container">
      <div class="section-head-row">
        <div><span class="eyebrow">Featured</span><h2>Start with something great</h2></div>
        <a class="btn btn-ghost btn-sm" href="/catalogue" data-link>View all ${icons.arrow}</a>
      </div>
      ${featured.length ? `<div class="grid">${featured.map(productCard).join('')}</div>`
        : `<div class="empty">New products are on their way. Check back soon.</div>`}
    </div></section>

    ${cats.length ? `<section class="section"><div class="container">
      <div class="section-head"><span class="eyebrow">Learning areas</span><h2>Explore by topic</h2><p>Pick an area you're curious about and see what's inside.</p></div>
      <div class="areas">
        ${cats.slice(0, 8).map((c, i) => `<a class="area" href="/catalogue?cat=${esc(c.slug)}" data-link>${areaIcons[i % 4]}<h4>${esc(c.name)}</h4><span>${countFor(c)} ${countFor(c) === 1 ? 'product' : 'products'}</span></a>`).join('')}
      </div>
    </div></section>` : ''}

    <section class="section dark" id="how"><div class="container">
      <div class="section-head"><span class="eyebrow" style="color:var(--gold)">How it works</span><h2>From curious to learning in four steps</h2></div>
      <div class="steps">
        <div class="step"><h4>Browse</h4><p>Explore the catalogue and open anything that interests you.</p></div>
        <div class="step"><h4>Get your access code</h4><p>Message us and complete your payment. We'll send you the current student code.</p></div>
        <div class="step"><h4>Enter the code</h4><p>Use it on the Student login page to unlock your learning space.</p></div>
        <div class="step"><h4>Start learning</h4><p>Watch the lessons, download the resources and track your progress.</p></div>
      </div>
    </div></section>

    ${faqTeaser()}

    <section class="section"><div class="container">
      <div class="cta-band">
        <h2>Ready to learn something new?</h2>
        <p>Browse the catalogue, or log in if you already have your student access code.</p>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
          <a class="btn btn-gold" href="/catalogue" data-link>Browse the catalogue</a>
          ${authed() ? '' : `<a class="btn btn-light" href="/login" data-link>Student login</a>`}
        </div>
      </div>
    </div></section>`
  };
}

/* ============ Catalogue ============ */
export async function catalogue({ query }) {
  const [products, cats] = await Promise.all([api.listProducts(), api.listCategories()]);
  const f = { type: query.type || '', cat: query.cat || '', q: query.q || '' };
  const usedTypes = TYPES.filter(t => products.some(p => p.type === t));

  const shell = `
  <section class="page-head"><div class="container">
    <span class="eyebrow">Catalogue</span>
    <h1>Courses &amp; digital products</h1>
    <p class="muted" style="max-width:560px">Everything available on The Digital Hub. Open any product to see what's inside.</p>
  </div></section>
  <section class="container" style="padding-bottom:90px">
    <div class="filters">
      ${usedTypes.length > 1 ? '<div class="filter-row" id="f-type"></div>' : ''}
      ${cats.length > 1 && products.length > 3 ? '<div class="filter-row" id="f-cat"></div>' : ''}
      ${products.length > 3 ? `<input class="search" id="f-q" type="search" placeholder="Search…" aria-label="Search the catalogue" value="${esc(f.q)}">` : ''}
    </div>
    <div id="results"></div>
  </section>`;

  const mount = root => {
    const paint = () => {
      const chip = (label, on, attr) => `<button class="chip ${on ? 'on' : ''}" ${attr}>${esc(label)}</button>`;
      const ft = $('#f-type', root);
      if (ft) ft.innerHTML = `<span class="filter-label">Type</span>` + chip('All', !f.type, 'data-type=""') +
        usedTypes.map(t => chip(typeMeta(t).plural, f.type === t, `data-type="${t}"`)).join('');
      const fc = $('#f-cat', root);
      if (fc) fc.innerHTML = `<span class="filter-label">Topic</span>` + chip('All', !f.cat, 'data-cat=""') +
        cats.map(c => chip(c.name, f.cat === c.slug, `data-cat="${esc(c.slug)}"`)).join('');
      const q = f.q.trim().toLowerCase();
      const list = products.filter(p =>
        (!f.type || p.type === f.type) && (!f.cat || p.category?.slug === f.cat) &&
        (!q || (p.title + ' ' + (p.subtitle || '') + ' ' + (p.description || '')).toLowerCase().includes(q)));
      $('#results', root).innerHTML = list.length
        ? `<div class="grid">${list.map(productCard).join('')}</div>`
        : `<div class="empty"><b>Nothing matches yet.</b><br>Try a different filter, or <button class="link-btn" id="clear">clear all filters</button>.</div>`;
      $('#clear', root)?.addEventListener('click', () => { f.type = f.cat = f.q = ''; const s = $('#f-q', root); if (s) s.value = ''; sync(); paint(); });
    };
    const sync = () => {
      const p = new URLSearchParams(); Object.entries(f).forEach(([k, v]) => v && p.set(k, v));
      history.replaceState({}, '', location.pathname + (p.toString() ? '?' + p : ''));
    };
    root.addEventListener('click', e => {
      const b = e.target.closest('.chip'); if (!b) return;
      if ('type' in b.dataset) f.type = b.dataset.type;
      if ('cat' in b.dataset) f.cat = b.dataset.cat;
      sync(); paint();
    });
    $('#f-q', root)?.addEventListener('input', e => { f.q = e.target.value; sync(); paint(); });
    paint();
  };
  return { title: 'Catalogue', html: shell, mount };
}

/* ============ Product page ============ */
export async function product({ params }) {
  const [p, s] = await Promise.all([api.getProduct(params.slug), api.getSettings()]);
  if (!p) return notFound();
  const m = typeMeta(p.type);
  const isCourse = p.type === 'video_course';
  const learnPath = `/learn/${p.slug}`;
  const here = '/p/' + p.slug;

  const cta = authed()
    ? `<div class="notice ok" style="margin-bottom:14px">${icons.check} You're logged in — this ${isCourse ? 'course' : 'product'} is unlocked.</div>
       <a class="btn btn-primary btn-block" href="${learnPath}" data-link>${isCourse ? 'Start learning' : 'Open product'} ${icons.arrow}</a>`
    : `<div class="notice info" style="margin-bottom:14px">${esc(s.accessInstructions || 'Contact us to get access.')}</div>
       ${s.contactLink ? `<a class="btn btn-primary btn-block" href="${esc(s.contactLink)}" target="_blank" rel="noopener">${esc(s.contactLabel || 'Get access')}</a>` : ''}
       <a class="btn ${s.contactLink ? 'btn-ghost' : 'btn-primary'} btn-block" style="margin-top:10px" href="/login?next=${encodeURIComponent(learnPath)}" data-link>I already have a code</a>`;

  const facts = [
    [icons.infinity, accessText(p)],
    isCourse ? [icons.play, `${p.lesson_count} video lesson${p.lesson_count === 1 ? '' : 's'}`] : [icons.file, m.label],
    [icons.download, 'Downloadable resources included'],
    [icons.lock, 'Private — unlocked with your student code']
  ];

  const html = `
  <div class="container">
    <div class="product-top">
      <div class="product-main">
        <div class="crumbs"><a href="/catalogue" data-link>Catalogue</a> / ${p.category ? `<a href="/catalogue?cat=${esc(p.category.slug)}" data-link>${esc(p.category.name)}</a> / ` : ''}${esc(p.title)}</div>
        <span class="badge">${m.icon}${esc(m.label)}</span>
        <h1 style="margin-top:12px">${esc(p.title)}</h1>
        ${p.subtitle ? `<p class="subtitle">${esc(p.subtitle)}</p>` : ''}
        ${coverArt(p, 'cover-lg')}

        <div class="product-block"><h2>About this ${isCourse ? 'course' : 'product'}</h2>
          ${(p.description || '').split(/\n\n+/).map(x => `<p class="muted">${esc(x)}</p>`).join('')}</div>

        ${p.outcomes?.length ? `<div class="product-block"><h2>${isCourse ? "What you'll learn" : "What you'll get"}</h2>
          <ul class="checklist">${p.outcomes.map(o => `<li>${icons.checkc}<span>${esc(o)}</span></li>`).join('')}</ul></div>` : ''}

        ${p.audience ? `<div class="product-block"><h2>Who it's for</h2><p class="muted">${esc(p.audience)}</p></div>` : ''}

        ${isCourse && p.lessons?.length ? `<div class="product-block"><h2>Curriculum</h2>
          <p class="muted small">${p.lessons.length} lesson${p.lessons.length === 1 ? '' : 's'}</p>
          <div class="curriculum">${p.lessons.map((l, i) => `
            <div class="cur-item"><span class="cur-num">${i + 1}</span>
              <div><h4>${esc(l.title)}</h4>${l.summary ? `<p>${esc(l.summary)}</p>` : ''}</div>
              <span class="cur-meta">${l.parts > 1 ? l.parts + ' parts · ' : ''}${l.duration_min ? `${icons.clock} ${l.duration_min} min` : icons.lock}</span></div>`).join('')}</div></div>` : ''}

        ${p.contents?.length ? `<div class="product-block"><h2>What's included</h2>
          <ul class="checklist">${p.contents.map(o => `<li>${icons.check}<span>${esc(o)}</span></li>`).join('')}</ul></div>` : ''}

        <div class="product-block"><h2>Access &amp; enrolment</h2>
          <p class="muted">${esc(accessText(p))}. Message us and complete your payment — once it's confirmed we'll send you the student access code. Enter it on the Student login page to unlock everything.</p></div>
      </div>

      <aside class="card buy-card">
        <div class="buy-body">
          <span class="price">${money(p.price_cents, p.currency)}</span>
          ${p.price_note ? `<span class="badge gold" style="margin-bottom:14px">${esc(p.price_note)}</span>` : '<div style="height:12px"></div>'}
          ${cta}
          <ul class="buy-facts">${facts.map(([ic, t]) => `<li>${ic}<span>${esc(t)}</span></li>`).join('')}</ul>
        </div>
      </aside>
    </div>
  </div>`;
  return { title: p.title, html };
}

/* ============ Student login (name + access code) ============ */
export const loginCard = (st, { hero = false } = {}) => {
  const H = hero ? 'h2' : 'h1';
  return `<div class="card auth-card ${hero ? 'hero-login' : ''}">
    <span class="badge gold" style="margin-bottom:14px">Student login</span>
    <${H}>${hero ? 'Log in to your classroom' : 'Welcome to your classroom'}</${H}>
    <p class="muted">Enter your name and the access code we sent you. That's all.</p>
    <div class="form-error" id="err" hidden></div>
    <form id="f" autocomplete="off" onsubmit="return false">
      <div class="form-row"><label for="name">1. Your name</label>
        <input id="name" class="big" type="text" required autocapitalize="words" autocomplete="given-name" enterkeyhint="next" placeholder="e.g. Tendai Moyo"></div>
      <div class="form-row"><label for="code">2. Your access code</label>
        <input id="code" class="big code-input" type="text" required autocapitalize="characters" autocomplete="off" spellcheck="false" enterkeyhint="go" placeholder="e.g. NOV-2026-XXXX"></div>
      <button class="btn btn-primary btn-block btn-lg" type="button" id="go">Enter my classroom ${icons.arrow}</button>
    </form>
    <p class="small center muted" style="margin:16px 0 0">Don't have a code yet? ${st.contactLink ? `<a href="${esc(st.contactLink)}" target="_blank" rel="noopener">${esc(st.contactLabel || 'Contact us')}</a> or ` : ''}<a href="/catalogue" data-link>browse the catalogue</a>.</p>
  </div>`;
};

export function bindLogin(root, dflt, query = {}) {
  const go = async () => {
    const btn = $('#go', root); if (btn.disabled) return;
    const showErr = m => { const b = $('#err', root); b.textContent = m; b.hidden = false; };
    const name = $('#name', root).value.trim(), code = $('#code', root).value.trim();
    if (name.length < 2) { showErr('Please enter your name.'); $('#name', root).focus(); return; }
    if (!code) { showErr('Please enter your access code.'); $('#code', root).focus(); return; }
    $('#err', root).hidden = true; btn.disabled = true; const label = btn.innerHTML; btn.textContent = 'Checking…';
    try {
      await api.login(name, code);
      window.dispatchEvent(new Event('hub:auth'));
      navigate(safeNext(query, dflt), { replace: true });
    } catch (err) {
      btn.disabled = false; btn.innerHTML = label; showErr(errMsg(err));
    }
  };
  $('#go', root).addEventListener('click', go);
  $('#name', root).addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#code', root).focus(); } });
  $('#code', root).addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
}

export async function login({ query }) {
  const dflt = landing(await api.listProducts());
  if (authed()) throw new Redirect(safeNext(query, dflt));
  const st = await api.getSettings();
  const html = `<div class="auth-wrap">${loginCard(st)}</div>`;
  const mount = root => { bindLogin(root, dflt, query); $('#name', root).focus(); };
  return { title: 'Student login', html, mount };
}

/* ============ FAQ ============ */

export async function faq() {
  const groups = state.faq || [];
  const st = await api.getSettings();
  const html = `
  <section class="page-head"><div class="container narrow">
    <span class="eyebrow">FAQ</span>
    <h1>Understanding AI, in plain words</h1>
    <p class="muted">Straight answers about AI, and about how your classroom works.</p>
  </div></section>
  <div class="container narrow" style="padding-bottom:90px">
    ${groups.map(g => `<h2 style="font-size:1.5rem;margin:34px 0 16px">${esc(g.group)}</h2>${g.items.map(faqItem).join('')}`).join('') || '<div class="empty">Questions coming soon.</div>'}
    <div class="card panel center" style="margin-top:40px"><h3>Still have a question?</h3>
      <p class="muted">${st.contactLink ? 'Send us a message and we\'ll help.' : 'Contact us and we\'ll help.'}</p>
      ${st.contactLink ? `<a class="btn btn-primary" href="${esc(st.contactLink)}" target="_blank" rel="noopener">${esc(st.contactLabel || 'Contact us')}</a>` : `<a class="btn btn-ghost" href="/catalogue" data-link>Browse the catalogue</a>`}</div>
  </div>`;
  return { title: 'FAQ', html };
}

const faqTeaser = () => {
  const top = (state.faq || []).flatMap(g => g.items).slice(0, 6);
  if (!top.length) return '';
  return `<section class="section tint" id="faq"><div class="container narrow">
    <div class="section-head center"><span class="eyebrow">FAQ</span><h2>Understanding AI, in plain words</h2><p>New to AI? Start with the questions most people ask.</p></div>
    ${top.map(faqItem).join('')}
    <div class="center" style="margin-top:26px"><a class="btn btn-ghost" href="/faq" data-link>See all questions ${icons.arrow}</a></div>
  </div></section>`;
};
